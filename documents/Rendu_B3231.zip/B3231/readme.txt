Utilisation du panel de test:
1) se rendre dans le dossier tests
2) lancer le script ./mktest.sh
3) les résultats sont disponibles sous forme de tableau(format csv) dans le fichier results.csv du dossier tests
		Interprétation:
			1 : test passé avec succès
			2 : test non effectué
			0 : test raté (erreur)


Descriptif des tests

TestAC:
Ajout d'un cercle (paramètres corrects)

TestAC01:
Ajout d'un cercle (1 paramètre manquant)

TestAC02:
Ajout d'un cercle (1 paramètre mal formaté (coordonnées ou rayon))
rayon : mauvais ou < 0

TestAC03:
Ajout d'un cercle avec le même nom qu'un autre

TestAL:
Ajout d'une ligne (paramètres corrects)

TestAL01:
Ajout d'une ligne (1 paramètre manquant)

TestAL02:
Ajout d'une ligne (1 paramètre mal formaté (coordonnées))

TestAL03:
Ajout d'une ligne avec le même nom qu'une autre

TestAP:
Ajout d'un polyligne (paramètres corrects)
1: polyligne à un seul point
2: polyligne à plusieurs points

TestAP01:
Ajout d'un polyligne (1 paramètre manquant <=> nombre impair de coordonnées)

TestAP02:
Ajout d'un polyligne (1 paramètre mal formaté (coordonnées))

TestAP03:
Ajout d'un polyligne avec le même nom qu'un autre

TestAR:
Ajout d'un rectangle (paramètres corrects)

TestAR01:
Ajout d'un rectangle (1 paramètre manquant)


TestAR02:
Ajout d'un rectangle (1 paramètre mal formaté (coordonnées))

TestAR03:
Ajout d'un rectangle avec le même nom qu'un autre

TestAS:
Ajout d'une sélection

TestAS01:
Ajout d'une sélection (paramètres incorrects)

TestC:
Clear le modèle:
1) Vide
2) Avec plusieurs objets

TestCS:
Création d'une selection
1) Vide
2) Englobant des objets

TestCS01:
Création d'une selection englobant des objets à ses limites (coordonnées limites des objets par rapport à la sélection)
1) 1 point commun
2) 2 points communs
3) 1 point en dehors

TestCS02:
Création d'une sélection avec de mauvaises coordonnées (non numériques)

TestDO:
Déplacement d'objets (tous types : C, R, L, PL, S)
1) positif
2) négatif
TestDO02:
Déplacement avec paramètre erronné (dx ou dy)

TestE:
Affichage de la liste de divers objets:
1) vide
2) non vide

TestL:
chargement d'un fichier:
1) normal, sans commentaire
2) avec commentaire

TestL01:
Chargement d'un fichier:
1) inexistant
2) vide
3) aucun nom spécifié

TestL02:
Chargement d'un fichier avec erreur (duplication de nom)
1) avec les objets en mémoire
2) au sein du fichier

TestR:
test de redo:
1) un seul
2) 20 d'affilée

TestR02:
REDO sans UNDO au préalable

TestS:
Sauvegarde du modèle courant dans un fichier:
1) vide
2) avec des objets

TestS01:
Tentative d'enregistrement sans droit d'écriture sur un fichier

TestSO:
Suppression de différents objets:
1) formes
2) sélection

TestU:
Annulation d'une opération
1) annulation des opérations d'insertion
2) annulation d'un LOAD
3) annulation d'un clear ou delete
TestU01:
Undo après l'objet création d'un objet puis d'une sélection

TestU02:
Undo après redo

TestU03:
un UNDO de trop

TestU04:
20 UNDO
