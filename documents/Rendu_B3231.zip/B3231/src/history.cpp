//---------------------------------------------------------------- INCLUDE

//--------------------------------------------------------- Local includes
#include "history.h"


/** @brief History : Default constructor. */
History::History()
{}


History::~History()
{}



/**
 * @brief clean : Cleans the current history (used if an operation is in the REDO list)
 */
void History::clean()
{}
